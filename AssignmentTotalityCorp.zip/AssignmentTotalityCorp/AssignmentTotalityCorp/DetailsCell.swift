//
//  DetailsCell.swift
//  AssignmentTotalityCorp
//
//  Created by Tejashree on 13/09/23.
//

import UIKit

class DetailsCell: UICollectionViewCell {
    
    static var reuseIdentifier = "DetailsCell"
    
    @IBOutlet weak var emptyView: UIView!
}
