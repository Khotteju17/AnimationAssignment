//
//  ViewController.swift
//  AssignmentTotalityCorp
//
//  Created by Tejashree on 11/09/23.
//

import UIKit

class ViewController: UIViewController {
    static var controller = "ViewController"
    
    @IBOutlet weak var componentView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        componentView.addGestureRecognizer(tap)
    }

    @objc func handleTap(_ sender: UITapGestureRecognizer){
        let story = UIStoryboard(name: "Main", bundle: nil)
        let controller = story.instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
        controller.modalPresentationStyle = .fullScreen
        self.present(controller, animated: true, completion: nil)
    }
    
}


