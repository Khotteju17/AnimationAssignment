//
//  DetailsViewController.swift
//  AssignmentTotalityCorp
//
//  Created by Tejashree on 11/09/23.
//

import Foundation
import UIKit

class DetailsViewController: UIViewController{
    static var controller = "DetailsViewController"
    
    @IBOutlet weak var downloadBtn: UIButton!
    @IBOutlet weak var downloadProgressBtn: UIButton!
    @IBOutlet weak var playBtn: UIButton!
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var animatingV: UIProgressView!
    @IBOutlet weak var animatingV2: UIProgressView!
    @IBOutlet weak var detailsCollectionView: UICollectionView!
    @IBOutlet weak var backgroundView: UIView!
    @IBOutlet weak var popUpView: UIView!
    @IBOutlet weak var nextBtn: UIButton!
    @IBOutlet weak var circleView1: UIView!
    @IBOutlet weak var circleView2: UIView!
    @IBOutlet weak var rectView1: UIView!
    @IBOutlet weak var rectView2: UIView!
    @IBOutlet weak var animationView2: UIView!
    @IBOutlet weak var animationView3: UIView!
    @IBOutlet weak var view5: UIView!
    @IBOutlet weak var view10: UIView!
    @IBOutlet weak var view15: UIView!
    @IBOutlet weak var balanceLabel: UILabel!
    @IBOutlet weak var balanceView: UIView!
    @IBOutlet weak var balanceView2: UIView!
    @IBOutlet weak var playLabel: UILabel!
    @IBOutlet weak var oswaldLabel: UILabel!
    @IBOutlet weak var oswaldView1: UIView!
    @IBOutlet weak var oswaldView2: UIView!
    @IBOutlet weak var oswaldView3: UIView!
    @IBOutlet weak var oswaldView4: UIView!
    @IBOutlet weak var oswaldView5: UIView!
    @IBOutlet weak var walletbalanceLabel: UILabel!
    @IBOutlet weak var walletbalanceView: UIView!
    @IBOutlet weak var walletbalanceView2: UIView!
    
    var isnextTapped = false
    var isplayTapped = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.detailsCollectionView.transform = CGAffineTransform(translationX: 150, y: 0)
        self.detailsCollectionView.isHidden = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.detailsCollectionView.reloadData()
            self.detailsCollectionView.isHidden = false
            UIView.animate(withDuration: 1.5, delay: 0.0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: .curveEaseInOut, animations: {
                self.detailsCollectionView.transform = CGAffineTransform(translationX: 0, y: 0)
            }) { (_) in
                UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseInOut, animations:{
                    
                }, completion: nil)
                
            }
            
        }
        
        animatingV.backgroundColor = UIColor.green
        cancelBtn.isHidden = true
        playBtn.isHidden = true
        animationView2.isHidden = true
        animationView3.isHidden = true
        animatingV.layer.masksToBounds = true
        animationView2.layer.masksToBounds = true
        animationView3.layer.masksToBounds = true
        
    // MARK: - TapGesture
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(playBtnClicked))
        self.view.addGestureRecognizer(tap)
        let gesture = UITapGestureRecognizer(target: self, action: #selector(nextBtnClicked))
        self.view.addGestureRecognizer(gesture)
    }
    
    // MARK: - IBActions
    
    @IBAction func viewClicked(_ sender : Any){
        animatingV.backgroundColor = .white
        downloadBtn.backgroundColor = .white
        setBatteryProgress(value: 80)
        cancelBtn.isHidden = false
        downloadBtn.isHidden = true
        downloadProgressBtn.isHidden = false
    }
    
    @IBAction func playBtnClicked(_ sender : Any){
        isplayTapped = true
        self.circleView1.transform = CGAffineTransform(translationX: 150, y: 0)
        self.rectView1.transform = CGAffineTransform(translationX: 150, y: 0)
        self.circleView2.transform = CGAffineTransform(translationX: 150, y: 0)
        self.rectView2.transform = CGAffineTransform(translationX: 150, y: 0)
        UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: .curveEaseInOut, animations: {
            self.circleView1.transform = CGAffineTransform(translationX: 0, y: 0)
            self.rectView1.transform = CGAffineTransform(translationX: 0, y: 0)
        }) { (_) in
            UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseInOut, animations:{
            }, completion: nil)
            
        }
        UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: .curveEaseInOut, animations: {
            self.circleView2.transform = CGAffineTransform(translationX: 0, y: 0)
            self.rectView2.transform = CGAffineTransform(translationX: 0, y: 0)
        }) { (_) in
            UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseInOut, animations:{
                
            }, completion: nil)
            
        }
        cancelBtn.isHidden = true
        backgroundView.isHidden = false
        popUpView.isHidden = false
        nextBtn.isHidden = false
        
    }
    
    @IBAction func nextBtnClicked(_ sender : Any){
        if !isnextTapped{
            isnextTapped = true
            animationView2.isHidden = false
            animationView3.isHidden = true
            self.view5.transform = CGAffineTransform(translationX: 150, y: 0)
            self.view10.transform = CGAffineTransform(translationX: 150, y: 0)
            self.view15.transform = CGAffineTransform(translationX: 150, y: 0)
            self.balanceLabel.transform = CGAffineTransform(translationX: 0, y: 50)
            self.balanceView.transform = CGAffineTransform(translationX: 0, y: 50)
            self.balanceView2.transform = CGAffineTransform(translationX: 0, y: 50)
            UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: .curveEaseInOut, animations: {
                self.view5.transform = CGAffineTransform(translationX: 0, y: 0)
                self.view10.transform = CGAffineTransform(translationX: 0, y: 0)
                self.balanceLabel.transform = CGAffineTransform(translationX: 0, y: 0)
                self.balanceView.transform = CGAffineTransform(translationX: 0, y: 0)
            }) { (_) in
                UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseInOut, animations:{
                    
                }, completion: nil)
                
            }
            UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: .curveEaseInOut, animations: {
                self.view10.transform = CGAffineTransform(translationX: 0, y: 0)
                self.view15.transform = CGAffineTransform(translationX: 0, y: 0)
                self.balanceView.transform = CGAffineTransform(translationX: 0, y: 0)
                self.balanceView2.transform = CGAffineTransform(translationX: 0, y: 0)
            }) { (_) in
                UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseInOut, animations:{
                    
                }, completion: nil)
                
            }
        }else{
            animationView3.isHidden = false
            animationView2.isHidden = true
            popUpView.isHidden = true
            animatingV.isHidden = true
            nextBtn.setTitle("Confirm", for: UIControl.State.normal)
            nextBtn.backgroundColor = .darkGray
            self.playLabel.transform = CGAffineTransform(translationX: 150, y: 0)
            self.oswaldLabel.transform = CGAffineTransform(translationX: 150, y: 0)
            self.oswaldView1.transform = CGAffineTransform(translationX: 150, y: 0)
            self.oswaldView2.transform = CGAffineTransform(translationX: 150, y: 0)
            self.oswaldView3.transform = CGAffineTransform(translationX: 0, y: 50)
            self.oswaldView4.transform = CGAffineTransform(translationX: 0, y: 50)
            self.oswaldView5.transform = CGAffineTransform(translationX: 0, y: 50)
            self.walletbalanceLabel.transform = CGAffineTransform(translationX: 0, y: 50)
            self.walletbalanceView.transform = CGAffineTransform(translationX: 0, y: 50)
            self.walletbalanceView2.transform = CGAffineTransform(translationX: 0, y: 50)
            UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: .curveEaseInOut, animations: {
                self.playLabel.transform = CGAffineTransform(translationX: 0, y: 0)
                self.oswaldLabel.transform = CGAffineTransform(translationX: 0, y: 0)
                self.oswaldView1.transform = CGAffineTransform(translationX: 0, y: 0)
                self.oswaldView2.transform = CGAffineTransform(translationX: 0, y: 0)
                self.oswaldView3.transform = CGAffineTransform(translationX: 0, y: 0)
                self.oswaldView4.transform = CGAffineTransform(translationX: 0, y: 0)
                self.oswaldView5.transform = CGAffineTransform(translationX: 0, y: 0)
                self.walletbalanceLabel.transform = CGAffineTransform(translationX: 0, y: 0)
                self.walletbalanceView.transform = CGAffineTransform(translationX: 0, y: 0)
            }) { (_) in
                UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseInOut, animations:{
                }, completion: nil)
                
            }
            UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: .curveEaseInOut, animations: {
                self.playLabel.transform = CGAffineTransform(translationX: 0, y: 0)
                self.oswaldLabel.transform = CGAffineTransform(translationX: 0, y: 0)
                self.oswaldView1.transform = CGAffineTransform(translationX: 0, y: 0)
                self.oswaldView2.transform = CGAffineTransform(translationX: 0, y: 0)
                self.oswaldView3.transform = CGAffineTransform(translationX: 0, y: 0)
                self.oswaldView4.transform = CGAffineTransform(translationX: 0, y: 0)
                self.oswaldView5.transform = CGAffineTransform(translationX: 0, y: 0)
                self.walletbalanceView.transform = CGAffineTransform(translationX: 0, y: 0)
                self.walletbalanceView2.transform = CGAffineTransform(translationX: 0, y: 0)
                
            }) { (_) in
                UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseInOut, animations:{
                }, completion: nil)
                
            }
            
            
            
        }
    }
    
    func setBatteryProgress(value: Int) {
        animatingV.setProgress(Float(value) / 100, animated: true)
        if (animatingV.progress <= 0.2) {
            self.animatingV.progressTintColor = UIColor.red
            animatingV2.isHidden = true
            if isplayTapped{
            }
        } else {
            animatingV.progressTintColor = .green
            print()
            if (animatingV.progress >= 0.8){
                cancelBtn.setImage(UIImage.init(named: "checkmark"), for: .normal)
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    self.animatingV.isHidden = true
                    self.playBtn.isHidden = false
                    self.cancelBtn.isHidden = true
                }
            }else{
            }
            
        }
    }
    
}
       
// MARK: - ClassAnimation

class AnimatingV:UIView {
    func animate() {
        let layer = CAGradientLayer()
        let startLocations = [0, 0]
        let endLocations = [1, 2]
        self.backgroundColor = .clear
        layer.colors = [UIColor.red.cgColor, UIColor.white.cgColor]
        layer.frame = self.frame
        layer.locations = startLocations as [NSNumber]
        layer.startPoint = CGPoint(x: 0.0, y: 1.0)
        layer.endPoint = CGPoint(x: 1.0, y: 1.0)
        self.layer.addSublayer(layer)
        
        let anim = CABasicAnimation(keyPath: "locations")
        anim.fromValue = startLocations
        anim.toValue = endLocations
        anim.duration = 5.0
        layer.add(anim, forKey: "loc")
        layer.locations = endLocations as [NSNumber]
    }
}

// MARK: - CollectionViewDelegates

extension DetailsViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: DetailsCell.reuseIdentifier, for: indexPath as IndexPath) as! DetailsCell
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize{
        let viewHeight = self.view.frame.size.height - 0
        let viewWidth = self.view.frame.size.width - 200
        return CGSize(width: viewWidth, height: viewHeight)
    }
    
}
